<?php
	class M_check_out extends CI_Model{
		
		function __construct() 
		{
        	parent::__construct();
        	
    	}

    	function selectStockData($dataSrch){
    	    
    	}

		public function countStockData($dataSrch){
		    
		}		
    }