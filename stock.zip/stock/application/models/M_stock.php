<?php
	class M_stock extends CI_Model{
		
		function __construct() 
		{
        	parent::__construct();
        	
    	}

    	function selectStockData($dataSrch){
    	    
    	}

		public function countStockData($dataSrch){
		    
		}		
    }