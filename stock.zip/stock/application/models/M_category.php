<?php
	class M_category extends CI_Model{
		
		function __construct() 
		{
        	parent::__construct();
        	
    	}
		
		function selectBrand($dataSrch){
		    
		}
		
    }