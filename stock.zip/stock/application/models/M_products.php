<?php
	class M_products extends CI_Model{
		
		function __construct() 
		{
        	parent::__construct();
        	
    	}

    	function selectProductsData($dataSrch){
    	    
    	}

    	public function countProductsData($dataSrch){
		    
		}		
    }