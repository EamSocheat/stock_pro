<?php
class M_user_account extends CI_Model{
		
		function __construct() 
		{
        	parent::__construct();
        	
    	}

    	function selectUserAccData($dataSrch){
    	    
    	}

    	public function countUserAccData($dataSrch){
		    
		}		
    }