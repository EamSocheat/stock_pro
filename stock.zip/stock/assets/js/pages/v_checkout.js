
var _pageNo = 1;
$(document).ready(function(){
	console.log("CHECKOUT")
	console.log(true)
});

var _thisPage = {
		onload : function(){
			
		}, loadData : function(page_no){
			
		}, editData : function(pos_id){
			
		}, addNewData : function(){
			
		}, deleteData : function(dataArr){
			
		}, event : function(){
			
		}
}

function popupPositionCallback(){
	
}




















